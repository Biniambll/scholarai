@echo off
title ScholarAI Desktop App Builder
color 0B
echo.
echo  ================================================
echo   ScholarAI Desktop App Builder for Windows
echo  ================================================
echo.

:: Check Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
  color 0C
  echo  [ERROR] Node.js is not installed!
  echo.
  echo  Please download and install Node.js from:
  echo  https://nodejs.org/en/download
  echo.
  echo  Then re-run this script.
  pause
  exit /b 1
)

echo  [OK] Node.js found: 
node --version
echo.

:: Check if scholarai.html exists
if not exist "scholarai.html" (
  color 0C
  echo  [ERROR] scholarai.html not found in this folder!
  echo.
  echo  Please copy scholarai.html into this folder and try again.
  echo  This folder should contain:
  echo    - scholarai.html
  echo    - main.js
  echo    - package.json
  echo    - build.bat  (this file)
  pause
  exit /b 1
)

echo  [OK] scholarai.html found
echo.
echo  Installing dependencies (this may take 1-2 minutes)...
echo.
npm install
if %errorlevel% neq 0 (
  color 0C
  echo  [ERROR] npm install failed. Check your internet connection.
  pause
  exit /b 1
)

echo.
echo  Building Windows installer (.exe)...
echo.
npm run build-win
if %errorlevel% neq 0 (
  color 0C
  echo  [ERROR] Build failed. See error above.
  pause
  exit /b 1
)

echo.
color 0A
echo  ================================================
echo   SUCCESS! Your .exe installer is ready.
echo  ================================================
echo.
echo  Location: dist\ScholarAI Setup 1.0.0.exe
echo.
echo  Share this file with anyone to install ScholarAI
echo  as a proper Windows desktop application.
echo.
pause
