#!/bin/bash
# ScholarAI Desktop App Builder for Mac / Linux

echo ""
echo "================================================"
echo "  ScholarAI Desktop App Builder"
echo "================================================"
echo ""

# Check Node.js
if ! command -v node &>/dev/null; then
  echo "❌ Node.js not found. Install from: https://nodejs.org"
  exit 1
fi
echo "✅ Node.js: $(node --version)"

# Check HTML file
if [ ! -f "scholarai.html" ]; then
  echo "❌ scholarai.html not found in this folder!"
  echo "   Copy scholarai.html here and try again."
  exit 1
fi
echo "✅ scholarai.html found"
echo ""

# Install deps
echo "📦 Installing dependencies..."
npm install || { echo "❌ npm install failed"; exit 1; }

# Detect OS and build
OS=$(uname)
echo ""
if [ "$OS" = "Darwin" ]; then
  echo "🍎 Building for macOS (.dmg)..."
  npm run build-mac || { echo "❌ Build failed"; exit 1; }
  echo ""
  echo "✅ Done! Installer: dist/ScholarAI-1.0.0.dmg"
else
  echo "🐧 Building for Linux (.AppImage)..."
  npm run build-linux || { echo "❌ Build failed"; exit 1; }
  echo ""
  echo "✅ Done! Installer: dist/ScholarAI-1.0.0.AppImage"
fi
echo ""
echo "================================================"
