╔══════════════════════════════════════════════════════════╗
║   ScholarAI Desktop App — Build Package v1.0            ║
║   © 2025 ScholarAI™. All rights reserved.               ║
╚══════════════════════════════════════════════════════════╝

WHAT'S IN THIS FOLDER
─────────────────────
  main.js          — Electron app entry point (with splash screen)
  package.json     — Build configuration
  LICENSE.txt      — Software license (shown in installer)
  BUILD-EXE.bat    — One-click Windows .exe builder
  build-mac.sh     — One-click Mac .dmg builder
  README.txt       — This file

  ❗ YOU MUST ADD:
  scholarai.html   — Copy your ScholarAI app file here!


HOW TO BUILD — WINDOWS (.exe)
──────────────────────────────
  1. Install Node.js from https://nodejs.org  (v18 or later)
  2. Copy scholarai.html into this folder
  3. Double-click BUILD-EXE.bat
  4. Wait ~3 minutes
  5. Find: dist\ScholarAI Setup 1.0.0.exe  ✓


HOW TO BUILD — MAC (.dmg)
──────────────────────────
  1. Install Node.js from https://nodejs.org
  2. Copy scholarai.html into this folder
  3. Open Terminal in this folder
  4. Run: chmod +x build-mac.sh && ./build-mac.sh
  5. Find: dist/ScholarAI-1.0.0.dmg  ✓


HOW TO TEST (without building)
────────────────────────────────
  1. Install Node.js
  2. Copy scholarai.html here
  3. Run in Terminal/CMD:
       npm install
       npm start
  4. ScholarAI opens as a desktop window  ✓


TROUBLESHOOTING
───────────────
  "npm not found"          → Install Node.js first
  "scholarai.html missing" → Copy the HTML file here
  "build fails"            → Run npm install first, then retry
  "white screen"           → scholarai.html must be in same folder as main.js
  "API not working"        → Internet connection required for AI features


COPYRIGHT NOTICE
────────────────
© 2025 ScholarAI™. All rights reserved.
ScholarAI and the ScholarAI logo are trademarks of ScholarAI.
Powered by Anthropic Claude AI.
Unauthorized reproduction or distribution is strictly prohibited.
