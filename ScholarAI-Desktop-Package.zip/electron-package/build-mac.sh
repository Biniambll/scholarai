#!/bin/bash
# ScholarAI Desktop App Builder — Mac
# © 2025 ScholarAI™. All rights reserved.

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   ScholarAI Desktop App Builder — Mac               ║"
echo "║   © 2025 ScholarAI™. All rights reserved.           ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

command -v node &>/dev/null || { echo "❌ Node.js not found. Install from: https://nodejs.org"; exit 1; }
echo "✅ Node.js: $(node --version)"

[ -f "scholarai.html" ] || { echo "❌ scholarai.html missing — copy it into this folder!"; exit 1; }
echo "✅ scholarai.html found"
echo ""

echo "📦 Installing dependencies..."
npm install || { echo "❌ npm install failed"; exit 1; }
echo ""

echo "🔨 Building Mac DMG..."
npm run build-mac || { echo "❌ Build failed"; exit 1; }
echo ""

echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✅ SUCCESS!                                         ║"
echo "║  dist/ScholarAI-1.0.0.dmg is ready to share.        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
open dist/ 2>/dev/null || echo "Find your file in: $(pwd)/dist/"
