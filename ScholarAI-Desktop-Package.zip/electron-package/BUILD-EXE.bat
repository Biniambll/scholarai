@echo off
title ScholarAI — Desktop App Builder v1.0
color 0B
cls
echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║        ScholarAI Desktop App Builder v1.0           ║
echo  ║        (c) 2025 ScholarAI. All rights reserved.     ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: ── Check Node.js ──────────────────────────────────────────
node --version >nul 2>&1
if %errorlevel% neq 0 (
  color 0C
  echo  [MISSING] Node.js is not installed.
  echo.
  echo  Please install Node.js v18+ from:
  echo  https://nodejs.org/en/download
  echo.
  echo  After installing, re-run this script.
  pause & exit /b 1
)
for /f %%v in ('node --version') do set NODE_VER=%%v
echo  [OK] Node.js %NODE_VER% detected
echo.

:: ── Check scholarai.html ────────────────────────────────────
if not exist "scholarai.html" (
  color 0C
  echo  [MISSING] scholarai.html not found!
  echo.
  echo  Copy scholarai.html into THIS folder:
  echo  %CD%
  echo.
  pause & exit /b 1
)
echo  [OK] scholarai.html found
echo.

:: ── Install dependencies ────────────────────────────────────
echo  [1/3] Installing Electron dependencies...
echo  (This downloads ~300MB on first run — please wait)
echo.
call npm install --silent
if %errorlevel% neq 0 (
  color 0C
  echo  [ERROR] npm install failed. Check internet connection.
  pause & exit /b 1
)
echo  [OK] Dependencies installed
echo.

:: ── Build Windows installer ─────────────────────────────────
echo  [2/3] Building Windows installer (.exe)...
echo  (This may take 2-3 minutes)
echo.
call npm run build-win
if %errorlevel% neq 0 (
  color 0C
  echo  [ERROR] Build failed. See error above.
  pause & exit /b 1
)
echo.

:: ── Done ────────────────────────────────────────────────────
color 0A
echo  [3/3] Complete!
echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║  SUCCESS! Your installer is ready:                  ║
echo  ║                                                      ║
echo  ║  dist\ScholarAI Setup 1.0.0.exe                     ║
echo  ║                                                      ║
echo  ║  Share this .exe with anyone to install ScholarAI   ║
echo  ║  as a proper Windows desktop application.           ║
echo  ╚══════════════════════════════════════════════════════╝
echo.
echo  Opening dist folder...
timeout /t 2 /nobreak >nul
start "" "%CD%\dist"
pause
