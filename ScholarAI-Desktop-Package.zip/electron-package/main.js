/**
 * ScholarAI Desktop App — Electron Main Process
 * © 2025 ScholarAI™. All rights reserved.
 * 
 * Place this file alongside scholarai.html and package.json
 * Run: npm install && npm start
 * Build: npm run build-win   (Windows .exe)
 *        npm run build-mac   (Mac .dmg)
 *        npm run build-linux (Linux AppImage)
 */

const { app, BrowserWindow, shell, Menu, dialog, nativeTheme } = require('electron');
const path = require('path');

// Force dark mode to match app theme
nativeTheme.themeSource = 'dark';

let mainWindow;
let splashWindow;

// ── SPLASH SCREEN ─────────────────────────────────────────────────────
function createSplash() {
  splashWindow = new BrowserWindow({
    width: 420, height: 280,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    center: true,
    resizable: false,
    skipTaskbar: true,
    webPreferences: { nodeIntegration: false, contextIsolation: true }
  });

  const splashHTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<style>
  * { box-sizing:border-box; margin:0; padding:0; }
  body {
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #0e0f14;
    border-radius: 16px;
    overflow: hidden;
    height: 280px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border: 1px solid #2a2d3e;
    box-shadow: 0 40px 80px #00000080;
    -webkit-app-region: drag;
  }
  .logo {
    font-size: 48px; margin-bottom: 16px;
    animation: pop .5s ease;
  }
  @keyframes pop { from{transform:scale(.6);opacity:0} to{transform:scale(1);opacity:1} }
  h1 {
    font-size: 28px; font-weight: 700;
    background: linear-gradient(135deg, #5b8af0, #a78bfa);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    margin-bottom: 6px; letter-spacing: -1px;
  }
  p { font-size: 12px; color: #6b7280; margin-bottom: 28px; }
  .bar-wrap {
    width: 200px; height: 3px;
    background: #2a2d3e; border-radius: 2px; overflow: hidden;
  }
  .bar {
    height: 100%; border-radius: 2px;
    background: linear-gradient(90deg, #5b8af0, #a78bfa, #f472b6);
    width: 0%; animation: load 1.8s ease forwards;
  }
  @keyframes load { 0%{width:0%} 60%{width:70%} 100%{width:100%} }
  .copy { font-size: 10px; color: #3a3d52; margin-top: 20px; }
</style>
</head>
<body>
  <div class="logo">🎓</div>
  <h1>ScholarAI</h1>
  <p>AI Research Writing Assistant</p>
  <div class="bar-wrap"><div class="bar"></div></div>
  <div class="copy">© 2025 ScholarAI™ — All rights reserved</div>
</body>
</html>`;

  splashWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(splashHTML)}`);
}

// ── MAIN WINDOW ───────────────────────────────────────────────────────
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 960,
    minHeight: 640,
    title: 'ScholarAI — Research Writing Assistant',
    backgroundColor: '#0e0f14',
    show: false,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
    }
  });

  mainWindow.loadFile('scholarai.html');

  // Show after splash (2 seconds)
  mainWindow.once('ready-to-show', () => {
    setTimeout(() => {
      if (splashWindow && !splashWindow.isDestroyed()) splashWindow.close();
      mainWindow.show();
      mainWindow.focus();
    }, 2000);
  });

  // Open links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Custom menu
  const menu = Menu.buildFromTemplate([
    {
      label: 'ScholarAI',
      submenu: [
        { label: 'About ScholarAI', click: showAbout },
        { type: 'separator' },
        { label: 'Quit ScholarAI', accelerator: 'CmdOrCtrl+Q', role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Undo', accelerator: 'CmdOrCtrl+Z', role: 'undo' },
        { label: 'Redo', accelerator: 'Shift+CmdOrCtrl+Z', role: 'redo' },
        { type: 'separator' },
        { label: 'Cut', accelerator: 'CmdOrCtrl+X', role: 'cut' },
        { label: 'Copy', accelerator: 'CmdOrCtrl+C', role: 'copy' },
        { label: 'Paste', accelerator: 'CmdOrCtrl+V', role: 'paste' },
        { label: 'Select All', accelerator: 'CmdOrCtrl+A', role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Reload', accelerator: 'CmdOrCtrl+R', role: 'reload' },
        { label: 'Zoom In', accelerator: 'CmdOrCtrl+=', role: 'zoomIn' },
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
        { type: 'separator' },
        { label: 'Toggle Fullscreen', accelerator: 'F11', role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Window',
      submenu: [
        { label: 'Minimize', accelerator: 'CmdOrCtrl+M', role: 'minimize' },
        { label: 'Maximize', click: () => mainWindow.maximize() },
      ]
    }
  ]);
  Menu.setApplicationMenu(menu);
}

function showAbout() {
  dialog.showMessageBox(mainWindow, {
    type: 'info',
    title: 'About ScholarAI',
    message: 'ScholarAI™',
    detail: `Version 1.0.0\n\nAI-Powered Research Writing Assistant\n\nPowered by Anthropic Claude AI\n\n© 2025 ScholarAI™\nAll rights reserved.\n\nUnauthorized reproduction or distribution of this software is strictly prohibited.`,
    buttons: ['OK'],
    icon: path.join(__dirname, 'icon.png')
  });
}

// ── APP LIFECYCLE ─────────────────────────────────────────────────────
app.whenReady().then(() => {
  createSplash();
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Security: prevent new window creation
app.on('web-contents-created', (_, contents) => {
  contents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
});
